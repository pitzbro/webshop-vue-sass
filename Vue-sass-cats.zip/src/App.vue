<template>
  <div id="app" class="main-layout">
    <header class="main-header" id="nav">
      <img class="logo" src="~@/assets/logo/cat-logo.gif" />
      <h1>My cat website</h1>
      <p>We’re all cat lovers. That’s why we’re here. But have you ever stopped to wonder why we find cats so incredible loveable?</p>
      <p>With Valentine’s Day just around the corner, it seemed the perfect time to explore our fascination with our self-domesticated feline friends.</p>
      <!-- <nav class="main-nav">
        <router-link to="/">Home</router-link>|
        <router-link to="/about">About</router-link>
      </nav> -->
    </header>
    <router-view />
    <footer class="main-footer">
      <small>all rights reserved to cats @2019</small>
    </footer>
  </div>
</template>

<style lang="scss">
</style>
