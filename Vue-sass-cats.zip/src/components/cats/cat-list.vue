<template>

</template>

<script>
export default {
  name: 'CatsList',
}
</script>
